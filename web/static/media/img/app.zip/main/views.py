from django.shortcuts import render
from django.views.generic import ListView, View, DetailView, CreateView
from django.db.models import Q


from .models import Movie, Category, Rating


class MoviesView(ListView):
    def get(self, request):
        categories = Category.objects.all()
        movies = Movie.objects.filter(Q(category__id=1))
        cartoons = Movie.objects.filter(Q(category__id=2))
        serial = Movie.objects.filter(Q(category__id=3))
        all = Movie.objects.all()
        popular = Rating.objects.order_by('star')
        popular_serial = Rating.objects.filter(movie__category__id=3).order_by('star')
        return render(request, 'main/cinematica.html', {"movie_list": movies,
                                                        "cartoon_list": cartoons,
                                                        "serial_list": serial,
                                                        "categories": categories,
                                                        "all": all,
                                                        "popular": popular,
                                                        "popular_serial": popular_serial,
                                                        }
                      )


class MovieDetailView(View):
    def get(self, request, slug):
        popular = Rating.objects.order_by('star')
        movie = Movie.objects.get(url=slug)
        return render(request, "main/movie_detail.html", {"movie": movie,
                                                          "popular": popular,
                                                          })




